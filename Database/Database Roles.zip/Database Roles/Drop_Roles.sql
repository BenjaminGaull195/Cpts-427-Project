--this file is used to drop the existing roles

DROP ROLE unregisteredUser;
DROP ROLE registeredUser;
DROP ROLE loginService;
drop ROLE bankAdmin;